var amoAd = (function(){
    var iframe = window.frameElement;
    var parentWindow = iframe.contentWindow.parent ? iframe.contentWindow.parent  : iframe.contentWindow;
    var bannerData = parentWindow.getBannerData()

    function init() {
        fireImpression();
        window.bannerData = bannerData;
    }


    function fireImpression() {
        if(bannerData.impressionTracker) {
            var impressionTrackers = bannerData.impressionTracker.split('^');
            impressionTrackers.forEach(function(url){
            if(url && url.toLowerCase() != 'na') {
                (new Image()).src = url;
            }
            });
        }
    }
    function getTextFromId(id) {
        let text = '';
        switch (id) {
            case 0: text = '12 months'; break;
            case 1: text = 'Deliver rich'; break;
            case 2: text = 'Get 55'; break;
            case 3: text = 'Build Azure'; break;
        }
        return text;
    }
    function click(text, id) {
        // console.log('click - ', getTextFromId(id));
        // parentWindow.amo.onDynAdClick(parentWindow.adData.feedData, "CLICK", parentWindow.adClickUrl.split('^').length > 1 && id >= 0 ? parentWindow.adClickUrl.split('^')[id] : parentWindow.adClickUrl, parentWindow.layout + '|' + bannerData.ctaText+ '|' + (currentSlide+1));
        if(id) {
            parentWindow.amo.onDynAdClick(parentWindow.adData.feedData, "CLICK", parentWindow.adClickUrl, parentWindow.layout + '|' + getTextFromId(id));
        } else {
            parentWindow.amo.onDynAdClick(parentWindow.adData.feedData, "CLICK", parentWindow.adClickUrl);
        }
    }
    function onInteraction(text, id) {
        // console.log('Interact - ', getTextFromId(id));
        var parentWindows = window.parent.parent.window;
        if (parentWindows && 'amoUtils' in parentWindows && 'onInteraction' in parentWindows.amoUtils) {
            try {
        var productId = ('id' in parentWindow.adData.feedData ? (parentWindow.adData.feedData.id) : '')
            // ProductID|SmartName or layout|CTA
            parentWindows.amoUtils.onInteraction(productId + '|' + parentWindow.layout + '|' + getTextFromId(id), parentWindow.adData.feedData);
            // parentWindows.amoUtils.onInteraction(productId + '|' + parentWindow.layout + '|' + bannerData.ctaText + ' - ' + text, parentWindow.adData.feedData);
                //parentWindows.amoUtils.onInteraction(parentWindow.layout + '|' + bannerData.ctaText + ' - ' + text + productId, parentWindow.adData.feedData);
            } catch (e) {}
        }
    }
    return {
        init: function(){ init(); },
        click: function(text, id) { click(text, id); },
        onInteraction: function(text, id) { onInteraction(text, id); },
    };
})();
