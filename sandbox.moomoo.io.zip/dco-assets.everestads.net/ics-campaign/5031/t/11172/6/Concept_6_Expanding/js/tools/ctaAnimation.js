let arrowCtaPlaying = 0;
let tlArrowCta = gsap.timeline()
  .to("#arrow g", { duration: 0.2, x: "+=60", ease: "power2.in", onStart: function () { arrowCtaPlaying = 1; } })
  .to("#arrow g", { duration: 0.01, x: "-=120" })
  .to("#arrow g", { duration: 0.4, x: "+=60", ease: "power2.Out", onComplete: function () { arrowCtaPlaying = 0; } })
  .pause();

