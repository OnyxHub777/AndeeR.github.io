let items = undefined;
let mainImages = undefined;
let smallImages = undefined;
let icons = undefined;
let headlines = undefined;
let teaseEffects = undefined;

let horizontal_line = undefined;
let vertical_line = undefined;

let lastIndex = undefined;

let auto_tl = undefined;
let tease_tl = undefined;
let firstFrame_tl = undefined;
let introTeaseEffect_tl = undefined;


let animationProgress = 0;
//0: introTease , 1: firstFrame, 2: autoplay, 3: interaction

let ZoomStatus = [0, 0, 0, 0];

const runBanner = () => {
    amoAd.init();
    showCopy(1);
    items = document.querySelectorAll('.item');
    mainImages = document.querySelectorAll('.mainImage');
    headlines = document.querySelectorAll('.headline');
    teaseEffects = document.querySelectorAll('.teaseEffect');
    horizontal_line = document.querySelectorAll('#horizontal_line');
    vertical_line = document.querySelectorAll('#vertical_line');

    gsap.set(teaseEffects, { alpha: 0 }, "<");
    gsap.set(mainImages, { filter: "contrast(0) brightness(2)", alpha: .3 });
    gsap.set([mainImages[0], mainImages[2]], { filter: "contrast(0)", });
    gsap.set(headlines, { x: -200, alpha: 0 });

    introTeaseEffect();
    triggerInteraction();
    createClickTags();
    playFirstFrame();
}

const playFirstFrame = () => {
    firstFrame_tl = gsap.timeline({
        paused: true,
        onComplete: () => {
            autoPlay();
        }
    });

    firstFrame_tl.to(mainImages[0], 1, { left: 105, top: 8, scale: 1, alpha: 1 }, "<")
    firstFrame_tl.to(mainImages[1], 1, { right: -8, top: 0, scale: 1, alpha: 0 }, "<")
    firstFrame_tl.to(mainImages[2], 1, { left: 83, bottom: -83, scale: 1, alpha: 0 }, "<")
    firstFrame_tl.to(mainImages[3], 1, { right: -32, bottom: -52, scale: 1, alpha: 0 }, "<")

    firstFrame_tl.add(() => {
        itemsEventHandler(0);
    }, "<")
}

const introTeaseEffect = () => {
    introTeaseEffect_tl = gsap.timeline({
        transformOrigin: '50% 50%', ease: 'none', ease: "power2.inOut",
        onComplete: () => {
            firstFrame_tl.play();
            animationProgress = 1;
        }
    })
        .to(mainImages[0], 1.5, { filter: "contrast(1)", alpha: 1 }, "<.5")
        .to(mainImages[1], 1.5, { filter: "contrast(1) brightness(1)", alpha: 1 }, "<.2")
        .to(mainImages[2], 1.5, { filter: "contrast(1) ", alpha: 1 }, "<.2")
        .to(mainImages[3], 1.5, { filter: "contrast(1) brightness(1)", alpha: 1 }, "<.2")

}

const autoChangeContent = () => {

    const width = [...items].map(item => gsap.getProperty(item, "width"));
    const height = [...items].map(item => gsap.getProperty(item, "height"));

    if (!width.includes(18) || !height.includes(18)) {
        for (let index = 0; index < 4; index++)
            if (width[index] < 155 || height[index] < 130) {
                if (ZoomStatus[index] == 1) continue;
                ZoomStatus[index] = 1;

                gsap.to(headlines[index], 1, { x: -200, alpha: 0, ease: "power2.out", overwrite: true });
                gsap.to(mainImages[index], 1, { alpha: 0, x: "+=200", ease: "power2.out", overwrite: true })
            }
            else {
                if (ZoomStatus[index] == 2) continue;
                ZoomStatus[index] = 2;

                gsap.to(headlines[index], 1, { x: 0, alpha: 1, ease: "power2.out", overwrite: true });
                gsap.to(mainImages[index], 1, { alpha: 1, x: 0, ease: "power2.out", overwrite: true });
            }
    }
}

const itemsEventHandler = (index) => {

    if (lastIndex == index) return;
    if(animationProgress == 3) {
        amoAd.onInteraction('', index);
    }
    if (index == 0) {
        gsap.to(items[0], 1, { width: '280px', height: '186px', overwrite: true });
        gsap.to(items[1], 1, { width: '20px', height: '186px', overwrite: true });
        gsap.to(items[2], 1, { width: '280px', height: '20px', overwrite: true });
        gsap.to(items[3], 1, { width: '20px', height: '20px', overwrite: true });

        gsap.to(horizontal_line, 1, { top: 185, overwrite: true });
        gsap.to(vertical_line, 1, { left: 279, overwrite: true });

    }
    else if (index == 1) {

        gsap.to(items[0], 1, { width: '20px', height: '186px', overwrite: true });
        gsap.to(items[1], 1, { width: '280px', height: '186px', overwrite: true });
        gsap.to(items[2], 1, { width: '20px', height: '20px', overwrite: true });
        gsap.to(items[3], 1, { width: '280px', height: '20px', overwrite: true });

        gsap.to(horizontal_line, 1, { top: 185, overwrite: true });
        gsap.to(vertical_line, 1, { left: 19, overwrite: true });
    }
    else if (index == 2) {

        gsap.to(items[0], 1, { width: '280px', height: '20px', overwrite: true });
        gsap.to(items[1], 1, { width: '20px', height: '20px', overwrite: true });
        gsap.to(items[2], 1, { width: '280px', height: '186px', overwrite: true });
        gsap.to(items[3], 1, { width: '20px', height: '186px', overwrite: true });

        gsap.to(horizontal_line, 1, { top: 19, overwrite: true });
        gsap.to(vertical_line, 1, { left: 279, overwrite: true });
    }
    else {

        gsap.to(items[0], 1, { width: '20px', height: '20px', overwrite: true });
        gsap.to(items[1], 1, { width: '280px', height: '20px', overwrite: true });
        gsap.to(items[2], 1, { width: '20px', height: '186px', overwrite: true });
        gsap.to(items[3], 1, { width: '280px', height: '186px', overwrite: true });

        gsap.to(horizontal_line, 1, { top: 19, overwrite: true });
        gsap.to(vertical_line, 1, { left: 19, overwrite: true });
    }
    lastIndex = index;
}

const createClickTags = ()=>{
    $(items).on("click", function () {
        const tags = [clickTag, clickTag1, clickTag2, clickTag3 ];
        // window.open(tags[$(this).index()]);
        amoAd.click('', $(this).index());

    });
}

const triggerInteraction = () => {
    $(items).on("mouseover", function () {
        // console.log('mouseover');
        if (animationProgress === 2) {
            // console.log('stop_autoplay');
            auto_tl.kill();
            tease_tl.kill();
            gsap.set(teaseEffects, { alpha: 0 }, "<");
            animationProgress = 3;
        }
        else if (animationProgress == 1) {
            return;
        }
        else if (animationProgress == 0) {

            gsap.timeline().to(items[0].children, 1, { scale: 1 }, "<")
                .to(items[1].children, 1, { scale: 1 }, "<")
                .to(items[2].children, 1, { scale: 1 }, "<")
                .to(items[3].children, 1, { scale: 1 }, "<")
            introTeaseEffect_tl.kill();

            gsap.to([mainImages[1], mainImages[3]], 1, { filter: "contrast(1) brightness(1)" });
            gsap.to([mainImages[0], mainImages[2]], 1, { filter: "contrast(1)" });

            firstFrame_tl.play();
            animationProgress = 1;
            return;
        }

        itemsEventHandler($(this).index());
    });
}

const autoPlay = () => {
    auto_tl = gsap.timeline({
        onStart: () => {
            tease_tl = gsap.timeline({
                overwrite: true, ease: 'none'
            });
            interactiveTeaseEffect(0);
            gsap.ticker.add(autoChangeContent);
            animationProgress = 2;
        },
        onComplete: () => {
            animationProgress = 3;
        }
    })
        .add(() => {
            itemsEventHandler(1);
            interactiveTeaseEffect(1);

        }, "<4.2")
        .add(() => {
            itemsEventHandler(2);
            interactiveTeaseEffect(2);

        }, "<4.2")
        .add(() => {
            itemsEventHandler(3);
            interactiveTeaseEffect(3);

        }, "<4.2")
}

const interactiveTeaseEffect = (index) => {
    if (index == 0)
        tease_tl.set(teaseEffects[2], { alpha: 1 }, "<1.5")
            .set([teaseEffects[1], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects[3], { alpha: 1 }, "<.5")
            .set([teaseEffects[1], teaseEffects[2]], { alpha: 0 }, "<")

            .set(teaseEffects[1], { alpha: 1 }, "<.5")
            .set([teaseEffects[2], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects, { alpha: 0 }, "<.5");
    if (index == 1)
        tease_tl.set(teaseEffects[0], { alpha: 1 }, "<1.5")
            .set([teaseEffects[2], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects[2], { alpha: 1 }, "<.5")
            .set([teaseEffects[0], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects[3], { alpha: 1 }, "<.5")
            .set([teaseEffects[0], teaseEffects[2]], { alpha: 0 }, "<")

            .set(teaseEffects, { alpha: 0 }, "<.5");
    else if (index == 2)
        tease_tl.set(teaseEffects[0], { alpha: 1 }, "<1.5")
            .set([teaseEffects[1], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects[1], { alpha: 1 }, "<.5")
            .set([teaseEffects[0], teaseEffects[3]], { alpha: 0 }, "<")

            .set(teaseEffects[3], { alpha: 1 }, "<.5")
            .set([teaseEffects[0], teaseEffects[1]], { alpha: 0 }, "<")

            .set(teaseEffects, { alpha: 0 }, "<.5");
    else if (index == 3)
        tease_tl.set(teaseEffects[2], { alpha: 1 }, "<1.5")
            .set([teaseEffects[0], teaseEffects[1]], { alpha: 0 }, "<")

            .set(teaseEffects[0], { alpha: 1 }, "<.5")
            .set([teaseEffects[1], teaseEffects[2]], { alpha: 0 }, "<")

            .set(teaseEffects[1], { alpha: 1 }, "<.5")
            .set([teaseEffects[0], teaseEffects[2]], { alpha: 0 }, "<")

            .set(teaseEffects, { alpha: 0 }, "<.5");
}


