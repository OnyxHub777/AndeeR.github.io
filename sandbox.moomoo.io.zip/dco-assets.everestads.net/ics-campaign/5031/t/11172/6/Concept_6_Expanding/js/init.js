function setSize(elements) {
    const data = $('meta[name="ad.size"]').attr('content');
    let ar1 = data.split(','), ar2 = [];

    for (let i = 0; i < ar1.length; i++) {
        let tmpAr = ar1[i].split('=');
        tmpAr[1] = eval(tmpAr[1]);
        ar2.push(tmpAr);
    }
    bannerSize = Object.fromEntries(new Map(ar2));

    $(elements).width(bannerSize.width).height(bannerSize.height);
}
setSize('#outline, #aria-text', 1);

function showCopy(n) {
    var copy = document.getElementsByClassName("copy");
    for (let i = 0; i < copy.length; i++) {
        if (n == 1) copy[i].style.visibility = "visible";
        if (n == 0) copy[i].style.visibility = "hidden";
    }
}

var initDiv = document.getElementById("init");
let exportRoot = {}, initReady = false;

function init() {
    if (!initReady) {
        startBanner();
    }
    gsap.delayedCall(0.4, function () {
        runBanner();
        initDiv.style.visibility = 'hidden';
    });
    initReady = true
}

let checkForFonts = 0;
for (let i = 0; i < fontToLoad.length; i++) {
    (function () {
        let fontTmp = new FontFace(fontToLoad[i][0], fontToLoad[i][1]);
        fontTmp.load().then(function (loaded_face) {
            document.fonts.add(loaded_face);
            checkForFonts++;
            if (checkForFonts == fontToLoad.length)
                loaded('font');
        }).catch(function (error) {
            //console.log("check font: " + error);
        });
    }());
}

var loadFont = false;
var loadBody = false;

function loaded(type) {
    if (type == 'font') loadFont = true;
    if (type == 'body') loadBody = true;
    if (loadFont && loadBody) init();
}

function startBanner() {
    $('#cta').click(exitHandler.bind(this));
    function exitHandler() {
        // window.open(clickTag4);
        amoAd.click('', lastIndex);
    }

}



$('#outline')
    .on('mouseenter', function () {
        if (arrowCtaPlaying !== 1) tlArrowCta.restart();
    });